# Script de limpieza para backend SOUP
# Ejecuta este script en PowerShell desde la carpeta backend para mover archivos de respaldo y eliminar basura

# Definir ruta de log
$logDir = "C:\Users\Ismael\Desktop\PROYECTO SOHA\SOUP\SOUP Emprendimientos\Informes\Informes Copilot"
if (!(Test-Path $logDir)) {
    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
}
$logFile = Join-Path $logDir "limpieza_backend_resultado.txt"

# Inicializar log
"--- LIMPIEZA BACKEND SOUP ---" | Out-File -FilePath $logFile -Encoding UTF8
"Fecha: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" | Out-File -FilePath $logFile -Append -Encoding UTF8

# Mover archivos de respaldo
$archivosRespaldo = @(
    '.\app\models_backup.py',
    '.\app\schemas_backup.py',
    '.\app\crud\product_backup.py',
    '.\app\routers\product_router_backup.py'
)
foreach ($archivo in $archivosRespaldo) {
    if (Test-Path $archivo) {
        Move-Item -Path $archivo -Destination .\backups\ -Force
        $msg = "Movido: $archivo -> .\\backups\\"
    } else {
        $msg = "No encontrado (no movido): $archivo"
    }
    $msg | Out-File -FilePath $logFile -Append -Encoding UTF8
}

# Eliminar archivos basura y temporales
$archivosBasura = @(
    '.\(c)',
    '.\await',
    '.\cd',
    '.\config.load()',
    '.\def',
    '.\File',
    '.\from',
    '.\Microsoft',
    '.\module',
    '.\Process',
    '.\return',
    '.\self.loaded_app',
    '.\self.run()',
    '.\target(sockets',
    '.\Traceback',
    '.\uvicorn',
    '.\^^^^^^^^',
    '.\^^^^^^^^^^^^^^',
    '.\^^^^^^^^^^^^^^^^^^^^',
    '.\^^^^^^^^^^^^^^^^^^^^^^^^^^',
    '.\←[32mINFO←[0m'
)
foreach ($archivo in $archivosBasura) {
    if (Test-Path $archivo) {
        Remove-Item -Path $archivo -Force -ErrorAction SilentlyContinue
        $msg = "Eliminado: $archivo"
    } else {
        $msg = "No encontrado (no eliminado): $archivo"
    }
    $msg | Out-File -FilePath $logFile -Append -Encoding UTF8
}

"\n---\nLimpieza finalizada. Revisa el archivo de log: $logFile" | Out-File -FilePath $logFile -Append -Encoding UTF8
Write-Host "\n---\nLimpieza finalizada. Revisa el archivo de log: $logFile"
