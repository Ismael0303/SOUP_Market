Archivos de respaldo y temporales movidos aquí para limpieza del backend.
