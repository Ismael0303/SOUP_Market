FormPart
========

In Shuup Admin forms often consist of multiple
`FormPart <shuup.admin.form_part.FormPart>` objects. They are also
widely used with the :doc:`provides system <../ref/provides>` to expand
the existing forms in admin.
