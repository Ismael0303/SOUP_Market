Shoop 2.0.0 Release Notes
=========================

Released on 2015-10-05 16:45 +0300.

The highlights of this release (over 500 commits since 1.2!) are:

- Revamp of the pricing and taxation systems for flexible international
  commerce
- A new pluggable frontend theming system called Xtheme
- Usability improvements for the admin, including much better media
  management
- A brand new, slick frontend theme "Classic Gray"
- Lots and lots of other fixes and improvements!

For more detailed list of changes see :doc:`../shoop-changelog` or `Git
commit log <https://github.com/shuup/shoop/commits/v2.0.0>`__.
