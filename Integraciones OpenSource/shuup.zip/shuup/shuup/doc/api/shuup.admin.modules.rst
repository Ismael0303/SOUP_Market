shuup\.admin\.modules package
=============================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.attributes
    shuup.admin.modules.categories
    shuup.admin.modules.contact_group_price_display
    shuup.admin.modules.contact_groups
    shuup.admin.modules.contacts
    shuup.admin.modules.currencies
    shuup.admin.modules.customers_dashboard
    shuup.admin.modules.labels
    shuup.admin.modules.manufacturers
    shuup.admin.modules.media
    shuup.admin.modules.menu
    shuup.admin.modules.orders
    shuup.admin.modules.permission_groups
    shuup.admin.modules.product_types
    shuup.admin.modules.products
    shuup.admin.modules.sales_dashboard
    shuup.admin.modules.sales_units
    shuup.admin.modules.service_providers
    shuup.admin.modules.services
    shuup.admin.modules.settings
    shuup.admin.modules.shops
    shuup.admin.modules.suppliers
    shuup.admin.modules.support
    shuup.admin.modules.system
    shuup.admin.modules.taxes
    shuup.admin.modules.users

Module contents
---------------

.. automodule:: shuup.admin.modules
    :members:
    :undoc-members:
    :show-inheritance:
