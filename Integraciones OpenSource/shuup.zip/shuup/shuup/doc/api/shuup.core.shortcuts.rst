shuup\.core\.shortcuts package
==============================

Module contents
---------------

.. automodule:: shuup.core.shortcuts
    :members:
    :undoc-members:
    :show-inheritance:
