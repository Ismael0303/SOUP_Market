shuup\.admin\.modules\.contact\_groups package
==============================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.contact_groups.views

Module contents
---------------

.. automodule:: shuup.admin.modules.contact_groups
    :members:
    :undoc-members:
    :show-inheritance:
