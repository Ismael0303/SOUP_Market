shuup\.customer\_group\_pricing package
=======================================

Submodules
----------

shuup\.customer\_group\_pricing\.admin\_form\_part module
---------------------------------------------------------

.. automodule:: shuup.customer_group_pricing.admin_form_part
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.customer\_group\_pricing\.models module
----------------------------------------------

.. automodule:: shuup.customer_group_pricing.models
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.customer\_group\_pricing\.module module
----------------------------------------------

.. automodule:: shuup.customer_group_pricing.module
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.customer\_group\_pricing\.signal\_handers module
-------------------------------------------------------

.. automodule:: shuup.customer_group_pricing.signal_handers
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.customer_group_pricing
    :members:
    :undoc-members:
    :show-inheritance:
