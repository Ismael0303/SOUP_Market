shuup\.front\.admin\_module\.companies package
==============================================

Submodules
----------

shuup\.front\.admin\_module\.companies\.form\_parts module
----------------------------------------------------------

.. automodule:: shuup.front.admin_module.companies.form_parts
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.admin_module.companies
    :members:
    :undoc-members:
    :show-inheritance:
