shuup\.campaigns\.admin\_module package
=======================================

Subpackages
-----------

.. toctree::

    shuup.campaigns.admin_module.forms
    shuup.campaigns.admin_module.views

Submodules
----------

shuup\.campaigns\.admin\_module\.form\_parts module
---------------------------------------------------

.. automodule:: shuup.campaigns.admin_module.form_parts
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.admin\_module\.form\_sets module
--------------------------------------------------

.. automodule:: shuup.campaigns.admin_module.form_sets
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.admin\_module\.sections module
------------------------------------------------

.. automodule:: shuup.campaigns.admin_module.sections
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.admin\_module\.utils module
---------------------------------------------

.. automodule:: shuup.campaigns.admin_module.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.campaigns.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
