shuup\.notify\.script\_template package
=======================================

Submodules
----------

shuup\.notify\.script\_template\.factory module
-----------------------------------------------

.. automodule:: shuup.notify.script_template.factory
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.notify\.script\_template\.generic module
-----------------------------------------------

.. automodule:: shuup.notify.script_template.generic
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.notify.script_template
    :members:
    :undoc-members:
    :show-inheritance:
