shuup\.testing\.models package
==============================

Module contents
---------------

.. automodule:: shuup.testing.models
    :members:
    :undoc-members:
    :show-inheritance:
