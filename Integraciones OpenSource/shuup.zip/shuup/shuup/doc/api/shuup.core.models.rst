shuup\.core\.models package
===========================

Module contents
---------------

.. automodule:: shuup.core.models
    :members:
    :undoc-members:
    :show-inheritance:
