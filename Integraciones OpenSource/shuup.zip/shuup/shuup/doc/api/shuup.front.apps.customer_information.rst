shuup\.front\.apps\.customer\_information package
=================================================

Submodules
----------

shuup\.front\.apps\.customer\_information\.dashboard\_items module
------------------------------------------------------------------

.. automodule:: shuup.front.apps.customer_information.dashboard_items
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.customer\_information\.forms module
-------------------------------------------------------

.. automodule:: shuup.front.apps.customer_information.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.customer\_information\.notify\_events module
----------------------------------------------------------------

.. automodule:: shuup.front.apps.customer_information.notify_events
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.customer\_information\.settings module
----------------------------------------------------------

.. automodule:: shuup.front.apps.customer_information.settings
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.customer\_information\.urls module
------------------------------------------------------

.. automodule:: shuup.front.apps.customer_information.urls
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.customer\_information\.views module
-------------------------------------------------------

.. automodule:: shuup.front.apps.customer_information.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.apps.customer_information
    :members:
    :undoc-members:
    :show-inheritance:
