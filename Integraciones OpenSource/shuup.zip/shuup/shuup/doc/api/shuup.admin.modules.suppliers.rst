shuup\.admin\.modules\.suppliers package
========================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.suppliers.views

Submodules
----------

shuup\.admin\.modules\.suppliers\.form\_parts module
----------------------------------------------------

.. automodule:: shuup.admin.modules.suppliers.form_parts
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.suppliers\.forms module
----------------------------------------------

.. automodule:: shuup.admin.modules.suppliers.forms
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.suppliers
    :members:
    :undoc-members:
    :show-inheritance:
