shuup\.front\.forms package
===========================

Submodules
----------

shuup\.front\.forms\.order\_forms module
----------------------------------------

.. automodule:: shuup.front.forms.order_forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.forms\.product\_list\_modifiers module
----------------------------------------------------

.. automodule:: shuup.front.forms.product_list_modifiers
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.forms\.product\_list\_supplier\_modifier module
-------------------------------------------------------------

.. automodule:: shuup.front.forms.product_list_supplier_modifier
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.forms\.widget module
----------------------------------

.. automodule:: shuup.front.forms.widget
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.forms
    :members:
    :undoc-members:
    :show-inheritance:
