shuup\.reports\.admin\_module package
=====================================

Submodules
----------

shuup\.reports\.admin\_module\.views module
-------------------------------------------

.. automodule:: shuup.reports.admin_module.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.reports.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
