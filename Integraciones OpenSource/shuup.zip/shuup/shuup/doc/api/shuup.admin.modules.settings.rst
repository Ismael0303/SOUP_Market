shuup\.admin\.modules\.settings package
=======================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.settings.form_parts
    shuup.admin.modules.settings.forms
    shuup.admin.modules.settings.views

Submodules
----------

shuup\.admin\.modules\.settings\.consts module
----------------------------------------------

.. automodule:: shuup.admin.modules.settings.consts
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.settings\.enums module
---------------------------------------------

.. automodule:: shuup.admin.modules.settings.enums
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.settings\.view\_settings module
------------------------------------------------------

.. automodule:: shuup.admin.modules.settings.view_settings
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.settings
    :members:
    :undoc-members:
    :show-inheritance:
