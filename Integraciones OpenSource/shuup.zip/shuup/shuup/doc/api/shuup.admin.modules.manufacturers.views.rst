shuup\.admin\.modules\.manufacturers\.views package
===================================================

Submodules
----------

shuup\.admin\.modules\.manufacturers\.views\.edit module
--------------------------------------------------------

.. automodule:: shuup.admin.modules.manufacturers.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.manufacturers\.views\.list module
--------------------------------------------------------

.. automodule:: shuup.admin.modules.manufacturers.views.list
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.manufacturers.views
    :members:
    :undoc-members:
    :show-inheritance:
