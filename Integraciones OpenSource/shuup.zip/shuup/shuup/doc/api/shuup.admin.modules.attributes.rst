shuup\.admin\.modules\.attributes package
=========================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.attributes.views

Submodules
----------

shuup\.admin\.modules\.attributes\.form\_parts module
-----------------------------------------------------

.. automodule:: shuup.admin.modules.attributes.form_parts
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.attributes\.forms module
-----------------------------------------------

.. automodule:: shuup.admin.modules.attributes.forms
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.attributes
    :members:
    :undoc-members:
    :show-inheritance:
