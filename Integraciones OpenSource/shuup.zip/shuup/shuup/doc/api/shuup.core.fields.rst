shuup\.core\.fields package
===========================

Submodules
----------

shuup\.core\.fields\.tagged\_json module
----------------------------------------

.. automodule:: shuup.core.fields.tagged_json
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.core\.fields\.utils module
---------------------------------

.. automodule:: shuup.core.fields.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.core.fields
    :members:
    :undoc-members:
    :show-inheritance:
