shuup\.front\.templatetags package
==================================

Submodules
----------

shuup\.front\.templatetags\.shuup\_front module
-----------------------------------------------

.. automodule:: shuup.front.templatetags.shuup_front
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.templatetags\.thumbnails module
---------------------------------------------

.. automodule:: shuup.front.templatetags.thumbnails
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.templatetags
    :members:
    :undoc-members:
    :show-inheritance:
