shuup\.notify\.admin\_module package
====================================

Subpackages
-----------

.. toctree::

    shuup.notify.admin_module.views

Submodules
----------

shuup\.notify\.admin\_module\.forms module
------------------------------------------

.. automodule:: shuup.notify.admin_module.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.notify\.admin\_module\.utils module
------------------------------------------

.. automodule:: shuup.notify.admin_module.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.notify.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
