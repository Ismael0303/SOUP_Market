shuup\.admin\.modules\.customers\_dashboard package
===================================================

Submodules
----------

shuup\.admin\.modules\.customers\_dashboard\.dashboard module
-------------------------------------------------------------

.. automodule:: shuup.admin.modules.customers_dashboard.dashboard
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.customers_dashboard
    :members:
    :undoc-members:
    :show-inheritance:
