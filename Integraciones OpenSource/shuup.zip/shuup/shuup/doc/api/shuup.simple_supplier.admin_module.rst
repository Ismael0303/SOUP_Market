shuup\.simple\_supplier\.admin\_module package
==============================================

Submodules
----------

shuup\.simple\_supplier\.admin\_module\.forms module
----------------------------------------------------

.. automodule:: shuup.simple_supplier.admin_module.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.simple\_supplier\.admin\_module\.views module
----------------------------------------------------

.. automodule:: shuup.simple_supplier.admin_module.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.simple_supplier.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
