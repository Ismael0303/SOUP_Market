shuup\.discounts\.admin\.modules package
========================================

Module contents
---------------

.. automodule:: shuup.discounts.admin.modules
    :members:
    :undoc-members:
    :show-inheritance:
