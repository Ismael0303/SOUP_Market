shuup\.admin\.modules\.categories package
=========================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.categories.views

Submodules
----------

shuup\.admin\.modules\.categories\.form\_parts module
-----------------------------------------------------

.. automodule:: shuup.admin.modules.categories.form_parts
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.categories\.forms module
-----------------------------------------------

.. automodule:: shuup.admin.modules.categories.forms
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.categories
    :members:
    :undoc-members:
    :show-inheritance:
