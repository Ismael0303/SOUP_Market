shuup\.discounts package
========================

Subpackages
-----------

.. toctree::

    shuup.discounts.admin
    shuup.discounts.management
    shuup.discounts.models

Submodules
----------

shuup\.discounts\.apps module
-----------------------------

.. automodule:: shuup.discounts.apps
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.discounts\.exceptions module
-----------------------------------

.. automodule:: shuup.discounts.exceptions
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.discounts\.modules module
--------------------------------

.. automodule:: shuup.discounts.modules
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.discounts\.plugins module
--------------------------------

.. automodule:: shuup.discounts.plugins
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.discounts\.settings module
---------------------------------

.. automodule:: shuup.discounts.settings
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.discounts\.signal\_handers module
----------------------------------------

.. automodule:: shuup.discounts.signal_handers
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.discounts\.utils module
------------------------------

.. automodule:: shuup.discounts.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.discounts
    :members:
    :undoc-members:
    :show-inheritance:
