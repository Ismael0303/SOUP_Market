shuup\.admin\.modules\.orders\.views package
============================================

Submodules
----------

shuup\.admin\.modules\.orders\.views\.addresses module
------------------------------------------------------

.. automodule:: shuup.admin.modules.orders.views.addresses
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.orders\.views\.detail module
---------------------------------------------------

.. automodule:: shuup.admin.modules.orders.views.detail
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.orders\.views\.edit module
-------------------------------------------------

.. automodule:: shuup.admin.modules.orders.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.orders\.views\.list module
-------------------------------------------------

.. automodule:: shuup.admin.modules.orders.views.list
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.orders\.views\.log module
------------------------------------------------

.. automodule:: shuup.admin.modules.orders.views.log
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.orders\.views\.payment module
----------------------------------------------------

.. automodule:: shuup.admin.modules.orders.views.payment
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.orders\.views\.refund module
---------------------------------------------------

.. automodule:: shuup.admin.modules.orders.views.refund
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.orders\.views\.shipment module
-----------------------------------------------------

.. automodule:: shuup.admin.modules.orders.views.shipment
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.orders\.views\.status module
---------------------------------------------------

.. automodule:: shuup.admin.modules.orders.views.status
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.orders.views
    :members:
    :undoc-members:
    :show-inheritance:
