shuup\.apps package
===================

Submodules
----------

shuup\.apps\.provides module
----------------------------

.. automodule:: shuup.apps.provides
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.apps\.settings module
----------------------------

.. automodule:: shuup.apps.settings
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.apps
    :members:
    :undoc-members:
    :show-inheritance:
