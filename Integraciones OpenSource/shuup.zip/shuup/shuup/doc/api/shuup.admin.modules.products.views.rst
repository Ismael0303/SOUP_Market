shuup\.admin\.modules\.products\.views package
==============================================

Submodules
----------

shuup\.admin\.modules\.products\.views\.copy module
---------------------------------------------------

.. automodule:: shuup.admin.modules.products.views.copy
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.views\.delete module
-----------------------------------------------------

.. automodule:: shuup.admin.modules.products.views.delete
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.views\.edit module
---------------------------------------------------

.. automodule:: shuup.admin.modules.products.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.views\.edit\_cross\_sell module
----------------------------------------------------------------

.. automodule:: shuup.admin.modules.products.views.edit_cross_sell
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.views\.edit\_media module
----------------------------------------------------------

.. automodule:: shuup.admin.modules.products.views.edit_media
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.views\.edit\_package module
------------------------------------------------------------

.. automodule:: shuup.admin.modules.products.views.edit_package
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.views\.edit\_parent module
-----------------------------------------------------------

.. automodule:: shuup.admin.modules.products.views.edit_parent
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.views\.list module
---------------------------------------------------

.. automodule:: shuup.admin.modules.products.views.list
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.views\.mass\_edit module
---------------------------------------------------------

.. automodule:: shuup.admin.modules.products.views.mass_edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.views\.toolbars module
-------------------------------------------------------

.. automodule:: shuup.admin.modules.products.views.toolbars
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.products.views
    :members:
    :undoc-members:
    :show-inheritance:
