shuup\.campaigns\.admin\_module\.forms package
==============================================

Module contents
---------------

.. automodule:: shuup.campaigns.admin_module.forms
    :members:
    :undoc-members:
    :show-inheritance:
