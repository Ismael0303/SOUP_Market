shuup\.front\.admin\_module\.carts package
==========================================

Subpackages
-----------

.. toctree::

    shuup.front.admin_module.carts.views

Submodules
----------

shuup\.front\.admin\_module\.carts\.form\_parts module
------------------------------------------------------

.. automodule:: shuup.front.admin_module.carts.form_parts
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.admin_module.carts
    :members:
    :undoc-members:
    :show-inheritance:
