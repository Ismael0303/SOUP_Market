shuup\.admin\.modules\.shops\.views package
===========================================

Submodules
----------

shuup\.admin\.modules\.shops\.views\.edit module
------------------------------------------------

.. automodule:: shuup.admin.modules.shops.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.shops\.views\.list module
------------------------------------------------

.. automodule:: shuup.admin.modules.shops.views.list
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.shops\.views\.wizard module
--------------------------------------------------

.. automodule:: shuup.admin.modules.shops.views.wizard
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.shops.views
    :members:
    :undoc-members:
    :show-inheritance:
