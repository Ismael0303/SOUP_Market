shuup\.discounts\.models package
================================

Module contents
---------------

.. automodule:: shuup.discounts.models
    :members:
    :undoc-members:
    :show-inheritance:
