shuup\.notify\.admin\_module\.views package
===========================================

Submodules
----------

shuup\.notify\.admin\_module\.views\.delete module
--------------------------------------------------

.. automodule:: shuup.notify.admin_module.views.delete
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.notify\.admin\_module\.views\.edit module
------------------------------------------------

.. automodule:: shuup.notify.admin_module.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.notify\.admin\_module\.views\.editor module
--------------------------------------------------

.. automodule:: shuup.notify.admin_module.views.editor
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.notify\.admin\_module\.views\.email\_template module
-----------------------------------------------------------

.. automodule:: shuup.notify.admin_module.views.email_template
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.notify\.admin\_module\.views\.list module
------------------------------------------------

.. automodule:: shuup.notify.admin_module.views.list
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.notify\.admin\_module\.views\.template module
----------------------------------------------------

.. automodule:: shuup.notify.admin_module.views.template
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.notify.admin_module.views
    :members:
    :undoc-members:
    :show-inheritance:
