shuup\.admin\.modules\.taxes\.views package
===========================================

Submodules
----------

shuup\.admin\.modules\.taxes\.views\.edit module
------------------------------------------------

.. automodule:: shuup.admin.modules.taxes.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.taxes\.views\.list module
------------------------------------------------

.. automodule:: shuup.admin.modules.taxes.views.list
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.taxes.views
    :members:
    :undoc-members:
    :show-inheritance:
