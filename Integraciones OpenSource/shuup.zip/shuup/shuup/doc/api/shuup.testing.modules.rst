shuup\.testing\.modules package
===============================

Subpackages
-----------

.. toctree::

    shuup.testing.modules.content
    shuup.testing.modules.demo
    shuup.testing.modules.mocker
    shuup.testing.modules.sample_data

Module contents
---------------

.. automodule:: shuup.testing.modules
    :members:
    :undoc-members:
    :show-inheritance:
