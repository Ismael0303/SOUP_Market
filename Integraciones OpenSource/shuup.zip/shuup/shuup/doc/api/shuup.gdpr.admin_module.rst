shuup\.gdpr\.admin\_module package
==================================

Submodules
----------

shuup\.gdpr\.admin\_module\.forms module
----------------------------------------

.. automodule:: shuup.gdpr.admin_module.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.admin\_module\.toolbar module
------------------------------------------

.. automodule:: shuup.gdpr.admin_module.toolbar
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.admin\_module\.views module
----------------------------------------

.. automodule:: shuup.gdpr.admin_module.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.gdpr.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
