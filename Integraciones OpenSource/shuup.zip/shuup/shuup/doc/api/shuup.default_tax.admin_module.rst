shuup\.default\_tax\.admin\_module package
==========================================

Submodules
----------

shuup\.default\_tax\.admin\_module\.views module
------------------------------------------------

.. automodule:: shuup.default_tax.admin_module.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.default_tax.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
