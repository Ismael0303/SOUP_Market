shuup\.admin\.modules\.permission\_groups package
=================================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.permission_groups.views

Module contents
---------------

.. automodule:: shuup.admin.modules.permission_groups
    :members:
    :undoc-members:
    :show-inheritance:
