shuup\.campaigns\.api package
=============================

Submodules
----------

shuup\.campaigns\.api\.serializers module
-----------------------------------------

.. automodule:: shuup.campaigns.api.serializers
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.campaigns.api
    :members:
    :undoc-members:
    :show-inheritance:
