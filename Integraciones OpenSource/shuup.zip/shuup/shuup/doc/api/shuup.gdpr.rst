shuup\.gdpr package
===================

Subpackages
-----------

.. toctree::

    shuup.gdpr.admin_module
    shuup.gdpr.templatetags

Submodules
----------

shuup\.gdpr\.anonymizer module
------------------------------

.. automodule:: shuup.gdpr.anonymizer
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.apps module
------------------------

.. automodule:: shuup.gdpr.apps
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.dashboard\_items module
------------------------------------

.. automodule:: shuup.gdpr.dashboard_items
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.forms module
-------------------------

.. automodule:: shuup.gdpr.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.models module
--------------------------

.. automodule:: shuup.gdpr.models
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.providers module
-----------------------------

.. automodule:: shuup.gdpr.providers
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.receivers module
-----------------------------

.. automodule:: shuup.gdpr.receivers
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.resources module
-----------------------------

.. automodule:: shuup.gdpr.resources
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.serializers module
-------------------------------

.. automodule:: shuup.gdpr.serializers
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.settings module
----------------------------

.. automodule:: shuup.gdpr.settings
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.signal\_handlers module
------------------------------------

.. automodule:: shuup.gdpr.signal_handlers
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.urls module
------------------------

.. automodule:: shuup.gdpr.urls
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.utils module
-------------------------

.. automodule:: shuup.gdpr.utils
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.gdpr\.views module
-------------------------

.. automodule:: shuup.gdpr.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.gdpr
    :members:
    :undoc-members:
    :show-inheritance:
