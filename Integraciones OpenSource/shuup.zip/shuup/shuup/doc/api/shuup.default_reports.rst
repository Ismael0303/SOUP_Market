shuup\.default\_reports package
===============================

Subpackages
-----------

.. toctree::

    shuup.default_reports.reports

Submodules
----------

shuup\.default\_reports\.apps module
------------------------------------

.. automodule:: shuup.default_reports.apps
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_reports\.forms module
-------------------------------------

.. automodule:: shuup.default_reports.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_reports\.mixins module
--------------------------------------

.. automodule:: shuup.default_reports.mixins
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.default_reports
    :members:
    :undoc-members:
    :show-inheritance:
