shuup\.simple\_cms\.admin\_module package
=========================================

Submodules
----------

shuup\.simple\_cms\.admin\_module\.form\_parts module
-----------------------------------------------------

.. automodule:: shuup.simple_cms.admin_module.form_parts
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.simple\_cms\.admin\_module\.views module
-----------------------------------------------

.. automodule:: shuup.simple_cms.admin_module.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.simple_cms.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
