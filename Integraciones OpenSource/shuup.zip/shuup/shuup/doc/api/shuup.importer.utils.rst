shuup\.importer\.utils package
==============================

Submodules
----------

shuup\.importer\.utils\.datastructures module
---------------------------------------------

.. automodule:: shuup.importer.utils.datastructures
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.importer\.utils\.fields module
-------------------------------------

.. automodule:: shuup.importer.utils.fields
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.importer\.utils\.importer module
---------------------------------------

.. automodule:: shuup.importer.utils.importer
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.importer.utils
    :members:
    :undoc-members:
    :show-inheritance:
