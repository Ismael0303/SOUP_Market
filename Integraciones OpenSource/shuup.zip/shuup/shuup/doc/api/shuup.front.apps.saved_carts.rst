shuup\.front\.apps\.saved\_carts package
========================================

Submodules
----------

shuup\.front\.apps\.saved\_carts\.dashboard\_items module
---------------------------------------------------------

.. automodule:: shuup.front.apps.saved_carts.dashboard_items
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.saved\_carts\.urls module
---------------------------------------------

.. automodule:: shuup.front.apps.saved_carts.urls
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.saved\_carts\.views module
----------------------------------------------

.. automodule:: shuup.front.apps.saved_carts.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.apps.saved_carts
    :members:
    :undoc-members:
    :show-inheritance:
