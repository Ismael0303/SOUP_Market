shuup\.default\_tax package
===========================

Subpackages
-----------

.. toctree::

    shuup.default_tax.admin_module

Submodules
----------

shuup\.default\_tax\.models module
----------------------------------

.. automodule:: shuup.default_tax.models
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_tax\.module module
----------------------------------

.. automodule:: shuup.default_tax.module
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.default_tax
    :members:
    :undoc-members:
    :show-inheritance:
