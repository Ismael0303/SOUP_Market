shuup\.gdpr\.templatetags package
=================================

Module contents
---------------

.. automodule:: shuup.gdpr.templatetags
    :members:
    :undoc-members:
    :show-inheritance:
